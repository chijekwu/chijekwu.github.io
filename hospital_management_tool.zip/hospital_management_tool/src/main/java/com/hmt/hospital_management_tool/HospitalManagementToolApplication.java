package com.hmt.hospital_management_tool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManagementToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalManagementToolApplication.class, args);
	}

}
