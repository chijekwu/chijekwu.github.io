package com.hmt.hospital_management_tool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagementToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
